#!/usr/bin/env python3
"""Download and locally georeference public NYC source data for the BridgePoint Manhattan Blender build.

Run with CPython 3.10+ (requires pyproj):
  python tools/reality_assets/download_manhattan_city_sources.py --output-dir /tmp/bp-manhattan-source

This script only downloads source data. It never modifies BridgePoint's production assets.
"""
from __future__ import annotations
import argparse, gzip, hashlib, json, math, os, sys, time
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

try:
    from pyproj import Transformer
except Exception as exc:  # pragma: no cover - exercised by CLI
    raise SystemExit("Missing dependency pyproj. Install it with: python -m pip install pyproj") from exc

USER_AGENT = "BridgePoint-Manhattan-Blender-Preview/1.0 (public NYC Open Data research build)"
# A city-wide bounding box enclosing Manhattan, Roosevelt Island, and its immediate waterfront.
BBOX = {"west": -74.03, "south": 40.67, "east": -73.90, "north": 40.89}
# Center point used as a local origin in EPSG:2263. All downloaded feature coordinates are
# transformed to local east/north metres from this exact projected origin.
ORIGIN_LON_LAT = (-73.9717, 40.7831)
FT_TO_M = 0.3048006096012192

SODA_DATASETS = {
    "roads": {"id": "inkn-q76z", "geometry_field": "the_geom", "title": "NYC Street Centerline (CSCL)", "url": "https://data.cityofnewyork.us/City-Government/Centerline/inkn-q76z"},
    "curbs": {"id": "5xvt-8cbk", "geometry_field": "the_geom", "title": "NYC Planimetric Database: Curbs", "url": "https://data.cityofnewyork.us/City-Government/NYC-Planimetric-Database-Curbs/5xvt-8cbk"},
    "sidewalks": {"id": "52n9-sdep", "geometry_field": "the_geom", "title": "NYC Planimetric Database: Sidewalk", "url": "https://data.cityofnewyork.us/City-Government/NYC-Planimetric-Database-Sidewalk/52n9-sdep"},
    "water": {"id": "pjs3-c3z5", "geometry_field": "the_geom", "title": "NYC Planimetric Database: Hydrography", "url": "https://data.cityofnewyork.us/Environment/NYC-Planimetric-Database-Hydrography/pjs3-c3z5"},
    "trees": {"id": "hn5i-inap", "geometry_field": "location", "title": "Forestry Tree Points (ForMS 2.0)", "url": "https://data.cityofnewyork.us/Environment/Forestry-Tree-Points/hn5i-inap"},
    "hydrants": {"id": "5bgh-vtsn", "geometry_field": "the_geom", "title": "NYC DEP Hydrants", "url": "https://data.cityofnewyork.us/Environment/Hydrants/5bgh-vtsn"},
    "boundary": {"id": "gthc-hcne", "geometry_field": "the_geom", "title": "NYC Borough Boundaries (Manhattan only)", "url": "https://data.cityofnewyork.us/City-Government/Borough-Boundaries/gthc-hcne"},
}
BUILDING_LAYER = "https://services6.arcgis.com/yG5s3afENB5iO9fj/ArcGIS/rest/services/BUILDING_view/FeatureServer/0"
BUILDING_DATASET_URL = "https://data.cityofnewyork.us/Housing-Development/Building-Footprints/5zhs-2jue"


def get_json(url: str, retries: int = 4, data: dict | None = None) -> dict:
    """Fetch JSON with GET by default, or form-encoded POST when data is supplied."""
    last = None
    for attempt in range(retries):
        try:
            headers = {"User-Agent": USER_AGENT, "Accept": "application/geo+json,application/json"}
            body = urlencode(data).encode("utf-8") if data is not None else None
            if body is not None:
                headers["Content-Type"] = "application/x-www-form-urlencoded"
            req = Request(url, data=body, headers=headers)
            with urlopen(req, timeout=90) as response:
                payload = response.read()
            return json.loads(payload.decode("utf-8"))
        except Exception as exc:
            last = exc
            if attempt + 1 < retries:
                time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"Unable to retrieve {url}: {last}")


def download_raw_file(repo_path: str, destination: Path) -> int:
    url = "https://raw.githubusercontent.com/olekingkole28-dot/bridgepoint-live/main/" + repo_path
    req = Request(url, headers={"User-Agent": USER_AGENT, "Accept-Encoding": "identity"})
    last = None
    for attempt in range(4):
        try:
            with urlopen(req, timeout=180) as response:
                data = response.read()
            if not data:
                raise RuntimeError("empty source response")
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
            return len(data)
        except Exception as exc:
            last = exc
            if attempt < 3:
                time.sleep(2 * (attempt + 1))
    raise RuntimeError(f"Unable to download existing Midtown LiDAR asset {url}: {last}")


def download_existing_midtown_lidar(out_dir: Path) -> dict:
    """Download only the already-reviewed 3x3 Midtown surface/orthophoto package."""
    import gzip
    root = "rebuild-v5000/assets/nyc-lidar"
    lidar_root = out_dir / "lidar"
    index_rel = root + "/tiles-index.json"
    index_path = lidar_root / "tiles-index.json"
    total_bytes = download_raw_file(index_rel, index_path)
    index = json.loads(index_path.read_text(encoding="utf-8"))
    tile_details = []
    for entry in index.get("tiles", []):
        manifest_rel = root + "/" + entry["manifest"]
        local_manifest = lidar_root / entry["manifest"]
        total_bytes += download_raw_file(manifest_rel, local_manifest)
        manifest = json.loads(local_manifest.read_text(encoding="utf-8"))
        tile_dir = Path(entry["manifest"]).parent
        surface = manifest.get("surfaceMesh", {})
        files = [surface.get("textureFile"), surface.get("wallFile")]
        files += [chunk.get("file") for chunk in surface.get("chunks", [])]
        tile_bytes = 0
        for filename in [x for x in files if x]:
            rel = str((Path(entry["manifest"]).parent / filename).as_posix())
            destination = lidar_root / rel
            if not destination.is_file():
                n = download_raw_file(root + "/" + rel, destination)
            else:
                n = destination.stat().st_size
            if filename.endswith(".gz"):
                with gzip.open(destination, "rb") as stream:
                    stream.read(4)
            tile_bytes += n
        total_bytes += tile_bytes
        tile_details.append({"tileId": entry["tileId"], "manifest": entry["manifest"],
                             "surfaceChunks": len(surface.get("chunks", [])), "wallQuads": surface.get("wallQuadCount", 0),
                             "assetBytes": tile_bytes, "texture": surface.get("textureFile")})
        print(f"MIDTOWN_LIDAR_TILE_READY {entry['tileId']} chunks={len(surface.get('chunks', []))} bytes={tile_bytes}", flush=True)
    return {"status": "DOWNLOADED", "tileCount": len(tile_details), "tiles": tile_details,
            "assetBytes": total_bytes, "sourceRepository": "olekingkole28-dot/bridgepoint-live",
            "sourceBasePath": root, "sourceNote": "Existing Midtown-only 3x3 2017 NYC LiDAR surfaces + NYS 2022-2025 orthophotos; not full-island coverage."}


def project_geometry(geometry: dict, transformer: Transformer, origin_xy: tuple[float, float]) -> dict:
    """Convert GeoJSON WGS84 coordinates to BridgePoint local ENU metres."""
    if not geometry:
        return geometry
    kind = geometry.get("type")
    coords = geometry.get("coordinates")
    if coords is None:
        return geometry
    ox, oy = origin_xy
    def point(p):
        x, y = transformer.transform(float(p[0]), float(p[1]))
        tail = list(p[2:]) if len(p) > 2 else []
        # The source vertical coordinate is not used for these planimetric data; preserve it if present.
        return [round((x - ox) * FT_TO_M, 4), round((y - oy) * FT_TO_M, 4), *tail]
    def walk(value):
        if isinstance(value, (list, tuple)) and len(value) >= 2 and isinstance(value[0], (int, float)) and isinstance(value[1], (int, float)):
            return point(value)
        if isinstance(value, (list, tuple)):
            return [walk(v) for v in value]
        return value
    return {"type": kind, "coordinates": walk(coords)}


def fetch_soda(name: str, spec: dict, out_dir: Path, transformer: Transformer, origin_xy: tuple[float, float], page_size: int) -> dict:
    endpoint = f"https://data.cityofnewyork.us/resource/{spec['id']}.geojson"
    # The borough layer has exactly five records; query it by borough code without a
    # spatial predicate. This avoids Socrata's within_box on complex MultiPolygon rows
    # returning an empty set and gives us the complete Manhattan land polygon for clipping.
    if name == "boundary":
        where = "borocode = 1"
    else:
        where = f"within_box({spec['geometry_field']},{BBOX['north']},{BBOX['west']},{BBOX['south']},{BBOX['east']})"
    features, offset, pages = [], 0, 0
    while True:
        params = {"$limit": page_size, "$offset": offset, "$where": where}
        url = endpoint + "?" + urlencode(params)
        doc = get_json(url)
        batch = doc.get("features", [])
        if not batch:
            break
        for feature in batch:
            geom = feature.get("geometry")
            if geom:
                feature["geometry"] = project_geometry(geom, transformer, origin_xy)
                features.append(feature)
        pages += 1
        offset += len(batch)
        print(f"SOURCE_PAGE {name} page={pages} rows={len(batch)} total={offset}", flush=True)
        if len(batch) < page_size:
            break
    result = {"type": "FeatureCollection", "name": name, "features": features,
              "bridgepointCoordinateFrame": "EPSG:2263-local-ENU-metres"}
    path = out_dir / f"{name}.geojson"
    path.write_text(json.dumps(result, separators=(",", ":")), encoding="utf-8")
    return {"name": name, "title": spec["title"], "datasetId": spec["id"], "sourceUrl": spec["url"],
            "downloadUrl": endpoint, "featureCount": len(features), "pages": pages, "file": path.name,
            "geometryField": spec["geometry_field"], "coordinateFrame": result["bridgepointCoordinateFrame"]}


def fetch_buildings(out_dir: Path, transformer: Transformer, origin_xy: tuple[float, float], page_size: int) -> dict:
    fields = "OBJECTID,BASE_BBL,BIN,CONSTRUCTION_YEAR,DOITT_ID,FEATURE_CODE,GEOM_SOURCE,GROUND_ELEVATION,HEIGHT_ROOF,LAST_EDITED_DATE,LAST_STATUS_TYPE,MAPPLUTO_BBL,NAME"
    id_url = BUILDING_LAYER + "/query?" + urlencode({
        "where": "BIN >= 1000000 AND BIN < 2000000", "returnIdsOnly": "true", "f": "json"
    })
    ids_doc = get_json(id_url)
    ids = ids_doc.get("objectIds") or []
    ids = sorted(set(int(v) for v in ids))
    if not ids:
        raise RuntimeError("The current NYC OTI BUILDING service returned no Manhattan BIN records.")
    features, pages = [], 0
    for start in range(0, len(ids), page_size):
        chunk = ids[start:start + page_size]
        # Keep large object-ID lists out of the URL. ArcGIS accepts form-encoded POST queries;
        # GET URLs with hundreds of IDs can be rejected by upstream URL-length limits (often as 404).
        params = {
            "objectIds": ",".join(str(v) for v in chunk),
            "outFields": fields, "returnGeometry": "true", "outSR": "4326", "f": "geojson"
        }
        doc = get_json(BUILDING_LAYER + "/query", data=params)
        batch = doc.get("features", [])
        for feature in batch:
            geom = feature.get("geometry")
            if geom:
                feature["geometry"] = project_geometry(geom, transformer, origin_xy)
                features.append(feature)
        pages += 1
        print(f"SOURCE_PAGE buildings page={pages} rows={len(batch)} total={len(features)}/{len(ids)}", flush=True)
    path = out_dir / "buildings.geojson"
    payload = {"type": "FeatureCollection", "name": "buildings", "features": features,
               "bridgepointCoordinateFrame": "EPSG:2263-local-ENU-metres"}
    path.write_text(json.dumps(payload, separators=(",", ":")), encoding="utf-8")
    return {"name": "buildings", "title": "NYC OTI current Building Footprints", "datasetId": "BUILDING_view/0",
            "sourceUrl": BUILDING_DATASET_URL, "serviceUrl": BUILDING_LAYER, "featureCount": len(features),
            "objectIdCount": len(ids), "pages": pages, "file": path.name,
            "heightFields": {"ground": "GROUND_ELEVATION (US survey feet, NAVD88-based)",
                             "roof": "HEIGHT_ROOF (feet above ground elevation)"},
            "coordinateFrame": payload["bridgepointCoordinateFrame"]}


def clip_feature_collection(payload: dict, boundary_shape, buffer_m: float = 0.0) -> dict:
    """Clip a local-metre GeoJSON-like collection to Manhattan's land polygon or a narrow water buffer."""
    try:
        from shapely.geometry import shape, mapping
    except Exception as exc:
        raise SystemExit("Missing dependency shapely. Install it with: python -m pip install shapely") from exc
    clip_shape = boundary_shape.buffer(buffer_m) if buffer_m > 0 else boundary_shape
    kept = []
    for feature in payload.get("features", []):
        geom = feature.get("geometry")
        if not geom:
            continue
        try:
            clipped = shape(geom).intersection(clip_shape)
        except Exception:
            continue
        if clipped.is_empty:
            continue
        # Drop geometry collections and lines/points not appropriate to this layer.
        expected = {
            "roads": ("LineString", "MultiLineString"),
            "curbs": ("LineString", "MultiLineString"),
            "sidewalks": ("Polygon", "MultiPolygon"),
            "water": ("Polygon", "MultiPolygon"),
            "trees": ("Point", "MultiPoint"),
            "hydrants": ("Point", "MultiPoint"),
        }.get(payload.get("name"), ())
        if expected and clipped.geom_type not in expected:
            # Keep only matching simple members of a GeometryCollection.
            parts = [g for g in getattr(clipped, "geoms", []) if g.geom_type in expected]
            if not parts:
                continue
            from shapely.ops import unary_union
            clipped = unary_union(parts) if len(parts) > 1 else parts[0]
        feature["geometry"] = mapping(clipped)
        kept.append(feature)
    payload["features"] = kept
    payload["clip"] = "Manhattan borough polygon" if buffer_m <= 0 else f"Manhattan borough polygon buffered {buffer_m:.0f} metres"
    return payload


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--page-size", type=int, default=20000)
    parser.add_argument("--building-page-size", type=int, default=350)
    parser.add_argument("--skip-midtown-lidar", action="store_true", help="Do not download the existing Midtown LiDAR tile package")
    args = parser.parse_args()
    if args.page_size < 100 or args.page_size > 50000:
        parser.error("--page-size must be between 100 and 50000")
    if args.building_page_size < 50 or args.building_page_size > 900:
        parser.error("--building-page-size must be between 50 and 900")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    to_2263 = Transformer.from_crs("EPSG:4326", "EPSG:2263", always_xy=True)
    origin_x_ft, origin_y_ft = to_2263.transform(*ORIGIN_LON_LAT)
    origin_xy = (origin_x_ft, origin_y_ft)
    sources = []
    sources.append(fetch_buildings(args.output_dir, to_2263, origin_xy, args.building_page_size))

    # The current DCP boundary is used as a true clip mask. This prevents Jersey, Queens,
    # Brooklyn and Bronx road furniture from leaking into the Manhattan prototype.
    boundary_spec = SODA_DATASETS["boundary"]
    boundary_source = fetch_soda("boundary", boundary_spec, args.output_dir, to_2263, origin_xy, args.page_size)
    boundary_payload = json.loads((args.output_dir / "boundary.geojson").read_text(encoding="utf-8"))
    try:
        from shapely.geometry import shape, mapping
        from shapely.ops import unary_union
        boundary_shapes = [shape(f["geometry"]) for f in boundary_payload.get("features", []) if f.get("geometry")]
        if not boundary_shapes:
            raise RuntimeError("Manhattan borough boundary geometry is empty.")
        manhattan_boundary = unary_union(boundary_shapes)
    except Exception as exc:
        raise SystemExit(f"Could not construct the Manhattan clip polygon: {exc}")
    boundary_payload["features"] = [{"type": "Feature", "properties": {"BOROCODE": 1, "BORONAME": "Manhattan"}, "geometry": mapping(manhattan_boundary)}]
    boundary_payload["name"] = "boundary"
    (args.output_dir / "boundary.geojson").write_text(json.dumps(boundary_payload, separators=(",", ":")), encoding="utf-8")
    boundary_source["featureCount"] = 1
    sources.append(boundary_source)

    for name, spec in SODA_DATASETS.items():
        if name == "boundary":
            continue
        try:
            source_info = fetch_soda(name, spec, args.output_dir, to_2263, origin_xy, args.page_size)
            payload = json.loads((args.output_dir / f"{name}.geojson").read_text(encoding="utf-8"))
            # Keep the adjacent water corridor so the Hudson and East River are visible.
            payload = clip_feature_collection(payload, manhattan_boundary, 450.0 if name == "water" else 0.0)
            (args.output_dir / f"{name}.geojson").write_text(json.dumps(payload, separators=(",", ":")), encoding="utf-8")
            source_info["featureCount"] = len(payload["features"])
            source_info["clip"] = payload.get("clip")
            sources.append(source_info)
        except Exception as exc:
            # Optional urban-detail sources are recorded explicitly, rather than silently omitted.
            print(f"SOURCE_WARNING {name}: {exc}", file=sys.stderr, flush=True)
            sources.append({"name": name, "title": spec["title"], "datasetId": spec["id"],
                            "sourceUrl": spec["url"], "file": None, "featureCount": 0, "error": str(exc)})

    lidar_report = {"status": "SKIPPED"}
    if not args.skip_midtown_lidar:
        try:
            lidar_report = download_existing_midtown_lidar(args.output_dir)
        except Exception as exc:
            print(f"SOURCE_WARNING midtown_lidar: {exc}", file=sys.stderr, flush=True)
            lidar_report = {"status": "FAILED", "error": str(exc)}

    manifest = {
        "schemaVersion": 1,
        "project": "BridgePoint Manhattan Blender City",
        "generatedAtUtc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "area": "Manhattan, New York City; bounding box includes Roosevelt Island and immediate waterfront",
        "bboxWgs84": BBOX,
        "coordinateReference": "EPSG:2263 NAD83 / New York Long Island (US survey feet)",
        "localOrigin": {"longitude": ORIGIN_LON_LAT[0], "latitude": ORIGIN_LON_LAT[1],
                        "projectedXFeet": origin_x_ft, "projectedYFeet": origin_y_ft,
                        "feetToMeters": FT_TO_M, "axes": "X east, Y north, Z up"},
        "sources": sources,
        "existingMidtownLiDAR": lidar_report,
        "important": [
            "Building footprints and roof heights are city-maintained source attributes; no building facade photography is included in this download.",
            "Facade windows, facade material variation, parapets, and rooftop mechanical props generated by the Blender build are procedural visual details, not surveyed observations.",
            "Road centerlines, curb lines, sidewalks, hydrography polygons and tree points are separate NYC public datasets; all are clipped to the Manhattan bounding box.",
            "Building heights with null or zero HEIGHT_ROOF values will be assigned a clearly recorded procedural fallback height.",
            "Coordinates in downloaded GeoJSON files have been transformed to local EPSG:2263 metres relative to localOrigin; do not treat them as WGS84 GeoJSON coordinates."
        ],
        "licenseAndAttribution": "Public NYC Open Data and NYC OTI service sources. Preserve source attribution and independently review NYC Open Data terms before redistribution."
    }
    (args.output_dir / "source-manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    total = sum(int(s.get("featureCount", 0)) for s in sources)
    print(f"MANHATTAN_SOURCES_COMPLETE files={len([s for s in sources if s.get('file')])} features={total}", flush=True)
    print(f"SOURCE_MANIFEST {args.output_dir / 'source-manifest.json'}", flush=True)

if __name__ == "__main__":
    main()
