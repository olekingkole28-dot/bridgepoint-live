#!/usr/bin/env python3
"""Build an isolated, source-labelled Manhattan city scene in Blender.

Run only inside Blender's Python:
  blender -b --python build_manhattan_blender_city.py -- \
    --source-dir /tmp/bp-manhattan-source --output-dir /tmp/bp-manhattan-output

The scene is a standalone prototype. It does not edit BridgePoint's web application,
its existing buildings, reality-assets catalog, or deployment settings.
"""
from __future__ import annotations
import argparse, gzip, json, math, os, random, struct, sys, time
from pathlib import Path

import bpy
from mathutils import Vector
from mathutils.kdtree import KDTree

FT_TO_M = 0.3048006096012192
POSITION_SCALE_M = 0.02


class MeshBuffer:
    def __init__(self, name):
        self.name = name
        self.vertices = []
        self.faces = []
        self.material_ids = []
        self.uvs = []

    def face(self, points, material=0, uv=None):
        start = len(self.vertices)
        self.vertices.extend(tuple(float(x) for x in p) for p in points)
        self.faces.append(tuple(range(start, start + len(points))))
        self.material_ids.append(int(material))
        if uv is not None:
            self.uvs.extend(tuple(float(x) for x in v) for v in uv)

    def triangle(self, a, b, c, material=0):
        self.face((a, b, c), material)

    def create_object(self, collection, materials=(), name=None):
        if not self.vertices or not self.faces:
            return None
        mesh = bpy.data.meshes.new(name or self.name)
        mesh.from_pydata(self.vertices, [], self.faces)
        mesh.update(calc_edges=True)
        obj = bpy.data.objects.new(name or self.name, mesh)
        collection.objects.link(obj)
        for material in materials:
            mesh.materials.append(material)
        for poly, material_id in zip(mesh.polygons, self.material_ids):
            poly.material_index = min(material_id, max(0, len(mesh.materials) - 1))
        if self.uvs and len(self.uvs) == len(self.vertices):
            layer = mesh.uv_layers.new(name="UVMap")
            for loop_index, loop in enumerate(mesh.loops):
                layer.data[loop_index].uv = self.uvs[loop.vertex_index]
        return obj


def prop(properties, *keys, default=None):
    if not isinstance(properties, dict):
        return default
    for key in keys:
        if key in properties and properties[key] not in (None, ""):
            return properties[key]
        low = key.lower()
        for candidate, value in properties.items():
            if str(candidate).lower() == low and value not in (None, ""):
                return value
    return default


def collection(name, parent):
    found = bpy.data.collections.get(name)
    if found:
        parent.children.link(found)
        return found
    item = bpy.data.collections.new(name)
    parent.children.link(item)
    return item


def principled(name, color, roughness=0.78, metallic=0.0):
    mat = bpy.data.materials.new(name)
    mat.diffuse_color = (*color, 1.0)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (*color, 1.0)
        bsdf.inputs["Roughness"].default_value = roughness
        bsdf.inputs["Metallic"].default_value = metallic
    return mat


def water_material():
    mat = principled("BP | Hudson + East River | procedural water", (0.018, 0.105, 0.145), 0.19, 0.42)
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        if "Coat Weight" in bsdf.inputs:
            bsdf.inputs["Coat Weight"].default_value = 0.28
        elif "Coat" in bsdf.inputs:
            bsdf.inputs["Coat"].default_value = 0.28
        if "Coat Roughness" in bsdf.inputs:
            bsdf.inputs["Coat Roughness"].default_value = 0.12
        noise = mat.node_tree.nodes.new("ShaderNodeTexNoise")
        noise.inputs["Scale"].default_value = 7.0
        noise.inputs["Detail"].default_value = 3.0
        bump = mat.node_tree.nodes.new("ShaderNodeBump")
        bump.inputs["Strength"].default_value = 0.11
        bump.inputs["Distance"].default_value = 0.18
        mat.node_tree.links.new(noise.outputs["Fac"], bump.inputs["Height"])
        mat.node_tree.links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])
    return mat


def polygons(geometry):
    if not geometry:
        return
    kind = geometry.get("type")
    coords = geometry.get("coordinates") or []
    if kind == "Polygon":
        yield coords
    elif kind == "MultiPolygon":
        for poly in coords:
            yield poly


def lines(geometry):
    if not geometry:
        return
    kind = geometry.get("type")
    coords = geometry.get("coordinates") or []
    if kind == "LineString":
        yield coords
    elif kind == "MultiLineString":
        for line in coords:
            yield line


def points(geometry):
    if not geometry:
        return
    kind = geometry.get("type")
    coords = geometry.get("coordinates") or []
    if kind == "Point":
        yield coords
    elif kind == "MultiPoint":
        yield from coords


def ring_xy(ring):
    result = [(float(p[0]), float(p[1])) for p in ring if len(p) >= 2]
    if len(result) > 1 and result[0] == result[-1]:
        result.pop()
    return result


def ring_centroid(ring):
    if not ring:
        return (0.0, 0.0)
    # Polygon centroid; stable fallback to mean for degenerate/very thin features.
    twice_area = 0.0
    cx = cy = 0.0
    for i, p in enumerate(ring):
        q = ring[(i + 1) % len(ring)]
        cross = p[0] * q[1] - q[0] * p[1]
        twice_area += cross
        cx += (p[0] + q[0]) * cross
        cy += (p[1] + q[1]) * cross
    if abs(twice_area) < 1e-6:
        return (sum(p[0] for p in ring) / len(ring), sum(p[1] for p in ring) / len(ring))
    return (cx / (3.0 * twice_area), cy / (3.0 * twice_area))


def signed_area(ring):
    total = 0.0
    for i, p in enumerate(ring):
        q = ring[(i + 1) % len(ring)]
        total += p[0] * q[1] - q[0] * p[1]
    return 0.5 * total


def point_in_ring(point, ring):
    x, y = point
    inside = False
    j = len(ring) - 1
    for i in range(len(ring)):
        xi, yi = ring[i]
        xj, yj = ring[j]
        if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-12) + xi):
            inside = not inside
        j = i
    return inside


def load_collection(path):
    if not path.is_file():
        return []
    doc = json.loads(path.read_text(encoding="utf-8"))
    return doc.get("features", [])


def style_index(year, feature_code):
    code = int(feature_code or 2100)
    if code in (1000, 1001, 1002, 5110):
        return 3  # industrial/parking
    if code == 5100:
        return 4  # under construction
    yr = int(year or 0)
    if yr and yr < 1946:
        return 0  # prewar masonry proxy
    if yr and yr < 1985:
        return 1  # postwar concrete / masonry proxy
    return 2  # modern / year unknown proxy


def estimated_height_m(area_m2, feature_code):
    code = int(feature_code or 2100)
    if code in (1000, 1001, 1002, 5110):
        return 5.5
    if area_m2 < 80: return 5.5
    if area_m2 < 220: return 8.5
    if area_m2 < 500: return 12.0
    if area_m2 < 1400: return 18.0
    if area_m2 < 3500: return 28.0
    if area_m2 < 9000: return 44.0
    return 62.0


class TerrainSampler:
    def __init__(self, samples):
        self.samples = samples
        self.tree = KDTree(len(samples))
        for i, (x, y, z) in enumerate(samples):
            self.tree.insert((x, y, 0.0), i)
        self.tree.balance()

    def height(self, x, y):
        found = self.tree.find((x, y, 0.0))
        if not found:
            return 0.0
        return float(self.samples[found[1]][2])

    def height_smooth(self, x, y):
        close = self.tree.find_n((x,y,0.0),4)
        if not close:
            return 0.0
        weighted=[]
        for co,idx,distance in close:
            weighted.append((float(self.samples[idx][2]),1.0/max(distance,5.0)**2))
        return sum(v*w for v,w in weighted)/sum(w for _,w in weighted)


def build_terrain(boundary_features, building_features, collection_root, report):
    boundary_polys = []
    for feature in boundary_features:
        for poly in polygons(feature.get("geometry")):
            if poly:
                boundary_polys.append(ring_xy(poly[0]))
    boundary = [r for r in boundary_polys if len(r) >= 4]
    if not boundary:
        report["terrain"] = {"status": "SKIPPED_NO_BOUNDARY"}
        return None, None

    samples = []
    for feature in building_features:
        p = feature.get("properties", {})
        ground_ft = prop(p, "GROUND_ELEVATION", "ground_elevation")
        if ground_ft is None:
            continue
        try:
            z = float(ground_ft) * FT_TO_M
        except (ValueError, TypeError):
            continue
        for poly in polygons(feature.get("geometry")):
            if not poly:
                continue
            ring = ring_xy(poly[0])
            if len(ring) >= 3:
                samples.append((*ring_centroid(ring), z))
                break
    if not samples:
        report["terrain"] = {"status": "SKIPPED_NO_GROUND_ELEVATION_SAMPLES"}
        return boundary, None

    min_x = min(p[0] for ring in boundary for p in ring); max_x = max(p[0] for ring in boundary for p in ring)
    min_y = min(p[1] for ring in boundary for p in ring); max_y = max(p[1] for ring in boundary for p in ring)
    spacing = 100.0
    xs = [min_x + i * spacing for i in range(int(math.ceil((max_x-min_x)/spacing)) + 1)]
    ys = [min_y + i * spacing for i in range(int(math.ceil((max_y-min_y)/spacing)) + 1)]
    sampler = TerrainSampler(samples)

    mesh = MeshBuffer("BP Manhattan | interpolated ground from OTI base elevations")
    vertex_index = {}
    for j, y in enumerate(ys):
        for i, x in enumerate(xs):
            if not any(point_in_ring((x, y), ring) for ring in boundary):
                continue
            z = sampler.height_smooth(x, y)
            vertex_index[(i, j)] = len(mesh.vertices)
            mesh.vertices.append((x, y, z))
    for j in range(len(ys)-1):
        for i in range(len(xs)-1):
            keys = ((i,j), (i+1,j), (i+1,j+1), (i,j+1))
            if all(k in vertex_index for k in keys):
                mesh.faces.append(tuple(vertex_index[k] for k in keys))
                mesh.material_ids.append(0)
    obj = mesh.create_object(collection_root, [principled("BP | interpolated NYC ground", (0.24,0.26,0.24), 0.95)])
    if obj:
        obj.name = "BP_GROUND_TERRAIN_INTERPOLATED_FROM_NYC_OTI_BUILDING_BASES"
    report["terrain"] = {"status": "BUILT", "sourceGroundSamples": len(samples),
                         "gridSpacingMeters": spacing, "vertices": len(mesh.vertices),
                         "faces": len(mesh.faces),
                         "method": "inverse-distance weighted interpolation of NYC OTI measured building base elevations; not a standalone LiDAR DTM"}
    return boundary, sampler


def make_window_face(builder, a, b, normal, z0, length, height, step_x, step_z, width, h):
    columns = max(0, int((length - 2.4) // step_x))
    floors = max(0, int((height - 2.0) // step_z))
    if columns <= 0 or floors <= 0:
        return 0
    # Limit pathological walls to keep a city-wide preview interactive.
    if columns > 65:
        columns = 65
    if floors > 26:
        floors = 26
    count = 0
    start = (length - (columns - 1) * step_x) * 0.5
    for row in range(floors):
        z = z0 + 1.25 + row * step_z
        if z + h >= z0 + height - 0.6:
            continue
        for col in range(columns):
            d = start + col * step_x
            cx = a[0] + (b[0]-a[0]) * (d / length)
            cy = a[1] + (b[1]-a[1]) * (d / length)
            x1 = cx - normal[0] * -0.035
            y1 = cy - normal[1] * -0.035
            x2 = x1 + normal[0] * 0.01
            y2 = y1 + normal[1] * 0.01
            # Window quads are recessed-looking dark glazing planes, slightly offset from the wall.
            p0 = (x1 - (b[0]-a[0])/length * width * 0.5, y1 - (b[1]-a[1])/length * width * 0.5, z)
            p1 = (x1 + (b[0]-a[0])/length * width * 0.5, y1 + (b[1]-a[1])/length * width * 0.5, z)
            p2 = (p1[0], p1[1], z + h)
            p3 = (p0[0], p0[1], z + h)
            builder.face((p0,p1,p2,p3), material=0)
            count += 1
    return count


def add_box(builder, cx, cy, z, sx, sy, sz, material=0, rotation=0.0):
    c, s = math.cos(rotation), math.sin(rotation)
    corners = []
    for dz in (0.0, sz):
        for y in (-sy/2, sy/2):
            for x in (-sx/2, sx/2):
                rx = x*c - y*s; ry = x*s + y*c
                corners.append((cx+rx, cy+ry, z+dz))
    # Bottom/top and four sides; faces use independently duplicated points to avoid normal seams.
    faces = ((0,1,3,2),(4,6,7,5),(0,4,5,1),(1,5,7,3),(3,7,6,2),(2,6,4,0))
    for face in faces:
        builder.face(tuple(corners[i] for i in face), material)


def add_tree_instance(builder, x, y, z, species, seed):
    rng = random.Random(seed)
    scale = rng.uniform(0.78, 1.22)
    trunk_h = rng.uniform(2.0, 3.2) * scale
    crown_h = rng.uniform(3.0, 5.2) * scale
    crown_w = rng.uniform(1.5, 2.7) * scale
    needle = any(k in str(species).lower() for k in ("pinus", "picea", "abies", "cedrus", "juniper", "spruce", "fir"))
    # Low-poly, joined tree geometry keeps the city file manageable. Species and points are
    # sourced, but the generated canopy mesh is a visual proxy rather than a species scan.
    sides = 6
    base = len(builder.vertices)
    for zz, radius in ((0.0,0.12*scale),(trunk_h,0.07*scale)):
        for i in range(sides):
            a = 2*math.pi*i/sides
            builder.vertices.append((x+math.cos(a)*radius, y+math.sin(a)*radius, z+zz))
    for i in range(sides):
        j=(i+1)%sides
        builder.faces.append((base+i,base+j,base+sides+j,base+sides+i)); builder.material_ids.append(0)
    if needle:
        apex = len(builder.vertices)
        builder.vertices.append((x, y, z+trunk_h+crown_h))
        ring = len(builder.vertices)
        for i in range(8):
            a=2*math.pi*i/8
            builder.vertices.append((x+math.cos(a)*crown_w*0.55, y+math.sin(a)*crown_w*0.55, z+trunk_h+crown_h*0.35))
        for i in range(8):
            builder.faces.append((apex,ring+i,ring+(i+1)%8)); builder.material_ids.append(2)
            builder.faces.append((base+sides+(i%sides),ring+(i+1)%8,ring+i)); builder.material_ids.append(2)
    else:
        # Two overlapping octagonal canopy lobes make a less uniform urban-tree silhouette.
        for lobe, zoff, radius in ((0,0.0,crown_w*0.66),(1,crown_h*0.26,crown_w*0.48)):
            center = (x + (rng.random()-0.5)*0.35, y + (rng.random()-0.5)*0.35, z+trunk_h+crown_h*0.35+zoff)
            center_i = len(builder.vertices); builder.vertices.append(center)
            ring_i = len(builder.vertices)
            for i in range(8):
                a=2*math.pi*i/8
                builder.vertices.append((center[0]+math.cos(a)*radius,center[1]+math.sin(a)*radius,center[2]+math.sin(a*2)*0.16*scale))
            for i in range(8):
                builder.faces.append((center_i,ring_i+i,ring_i+(i+1)%8)); builder.material_ids.append(1 if lobe==0 else 2)


def add_curb_curves(features, collection_root, terrain_tree, materials):
    curve = bpy.data.curves.new("BP | NYC measured curb lines", "CURVE")
    curve.dimensions = "3D"
    curve.resolution_u = 1
    curve.bevel_depth = 0.085
    curve.bevel_resolution = 1
    curve.resolution_u = 1
    for feature in features:
        for line in lines(feature.get("geometry")):
            coords = [(float(p[0]),float(p[1])) for p in line if len(p)>=2]
            if len(coords) < 2:
                continue
            spline = curve.splines.new("POLY")
            spline.points.add(len(coords)-1)
            for i,(x,y) in enumerate(coords):
                z = terrain_height(terrain_tree, x, y) + 0.13
                spline.points[i].co = (x,y,z,1.0)
    obj = bpy.data.objects.new("BP_NYC_CURBS | sourced planimetric edges", curve)
    collection_root.objects.link(obj)
    if materials:
        curve.materials.append(materials[0])
    return obj


def terrain_height(tree, x, y):
    if tree is None:
        return 0.0
    return tree.height(x, y)


def build_surfaces(name, features, col, material, kind, terrain_tree):
    mesh = MeshBuffer(name)
    count = 0
    for feature in features:
        geom = feature.get("geometry")
        for poly in polygons(geom):
            if not poly:
                continue
            outer = ring_xy(poly[0])
            if len(outer) < 3:
                continue
            zoff = 0.15 if kind == "sidewalk" else -0.25
            pts = [(x,y,terrain_height(terrain_tree,x,y)+zoff) for x,y in outer]
            mesh.face(pts, 0)
            count += 1
    obj = mesh.create_object(col, [material])
    if obj:
        obj.name = name
    return count


def build_road_ribbons(features, col, material, terrain_tree):
    mesh = MeshBuffer("BP Manhattan | road bed ribbons from NYC centerline")
    count=0
    for feature in features:
        p=feature.get("properties",{})
        label=(str(prop(p,"pre_type","PRE_TYPE",default=""))+" "+str(prop(p,"post_type","POST_TYPE",default=""))).upper()
        width=11.5 if any(k in label for k in ("AVENUE","BOULEVARD","PARKWAY","EXPRESSWAY")) else 7.2
        for line in lines(feature.get("geometry")):
            coords=[(float(q[0]),float(q[1])) for q in line if len(q)>=2]
            if len(coords)<2: continue
            for i in range(len(coords)-1):
                a,b=coords[i],coords[i+1]
                dx,dy=b[0]-a[0],b[1]-a[1]
                length=math.hypot(dx,dy)
                if length<1.0: continue
                nx,ny=-dy/length*width*0.5,dx/length*width*0.5
                z0=terrain_height(terrain_tree,*a)+0.06
                z1=terrain_height(terrain_tree,*b)+0.06
                mesh.face(((a[0]+nx,a[1]+ny,z0),(b[0]+nx,b[1]+ny,z1),(b[0]-nx,b[1]-ny,z1),(a[0]-nx,a[1]-ny,z0)),0)
                count+=1
    obj=mesh.create_object(col,[material])
    if obj: obj.name="BP_NYC_ROADS | approximate width from street class; source centerline geometry"
    return count


def build_hydrants(features, col, terrain_tree, metal_mat):
    mesh=MeshBuffer("BP Manhattan | hydrants from NYC DEP locations")
    count=0
    for f in features:
        for p in points(f.get("geometry")):
            if len(p)<2: continue
            x,y=float(p[0]),float(p[1]); z=terrain_height(terrain_tree,x,y)+0.1
            add_box(mesh,x,y,z,0.26,0.26,0.58,0)
            count+=1
    obj=mesh.create_object(col,[metal_mat])
    if obj: obj.name="BP_NYC_HYDRANTS | sourced point locations, procedural 3D form"
    return count


def import_midtown_lidar(lidar_dir, col, local_origin, report):
    index_path=lidar_dir/"tiles-index.json"
    if not index_path.is_file():
        report["midtownLidar"]={"status":"NOT_DOWNLOADED"}
        return
    index=json.loads(index_path.read_text(encoding="utf-8"))
    ox,oy=local_origin
    tile_count=0; total_triangles=0
    # One material per tile keeps real orthophoto pixels aligned with the source mesh.
    for entry in index.get("tiles",[]):
        tile_id=str(entry.get("tileId"))
        manifest_rel=Path(entry["manifest"])
        manifest_path=lidar_dir/manifest_rel
        if not manifest_path.is_file():
            continue
        manifest=json.loads(manifest_path.read_text(encoding="utf-8"))
        anchor=manifest.get("anchor",{})
        ax=float(anchor.get("projectedXFeet",0))*FT_TO_M-ox
        ay=float(anchor.get("projectedYFeet",0))*FT_TO_M-oy
        az=float(anchor.get("verticalOriginFeet",0))*FT_TO_M
        tile_dir=manifest_path.parent
        surface=manifest.get("surfaceMesh",{})
        texture_path=tile_dir/surface.get("textureFile","")
        mat=principled("BP | measured NYS orthophoto tile "+tile_id,(0.6,0.6,0.6),0.95)
        if texture_path.is_file():
            try:
                img=bpy.data.images.load(str(texture_path),check_existing=True)
                img.pack()
                tex=mat.node_tree.nodes.new("ShaderNodeTexImage"); tex.image=img
                bsdf=mat.node_tree.nodes.get("Principled BSDF")
                mat.node_tree.links.new(tex.outputs["Color"],bsdf.inputs["Base Color"])
            except Exception as exc:
                print("LIDAR_TEXTURE_WARNING",tile_id,str(exc),flush=True)
        for chunk in surface.get("chunks",[]):
            file_path=tile_dir/chunk.get("file","")
            if not file_path.is_file(): continue
            raw=gzip.decompress(file_path.read_bytes())
            vc=int(chunk["vertexCount"]); ic=int(chunk["indexCount"])
            if len(raw)!=vc*10+ic*4:
                raise RuntimeError("LiDAR surface chunk length mismatch: "+str(file_path))
            pos=struct.unpack_from("<"+"h"*(vc*3),raw,0)
            uv_offset=vc*6
            uv=struct.unpack_from("<"+"H"*(vc*2),raw,uv_offset)
            idx=struct.unpack_from("<"+"I"*ic,raw,vc*10)
            verts=[]
            for i in range(vc):
                qx,qz,qn=pos[i*3:i*3+3]
                verts.append((ax+qx*POSITION_SCALE_M, ay+qn*POSITION_SCALE_M, az+qz*POSITION_SCALE_M))
            # create faces in one Blender mesh; triangle winding is adjusted to Blender ENU.
            bm=MeshBuffer("BP measured LiDAR surface "+tile_id)
            bm.vertices.extend(verts)
            for i in range(0,ic,3):
                bm.faces.append((idx[i],idx[i+1],idx[i+2])); bm.material_ids.append(0)
            bm.uvs.extend((uv[i]/65535.0,uv[i+1]/65535.0) for i in range(0,len(uv),2))
            obj=bm.create_object(col,[mat],"BP_MIDTOWN_LIDAR_ROOF_GROUND_"+tile_id+"_PART_"+str(chunk.get("part",0)))
            if obj:
                total_triangles+=ic//3
        # Wall buffer: xyz int16, rgb uint8, then triangle indices uint32.
        wall_meta=surface
        wall_path=tile_dir/wall_meta.get("wallFile","")
        if wall_path.is_file():
            raw=gzip.decompress(wall_path.read_bytes())
            vcount=int(wall_meta.get("wallVertexCount",0)); icount=int(wall_meta.get("wallIndexCount",0))
            expected=vcount*9+icount*4
            if len(raw)==expected and vcount>0:
                pos=struct.unpack_from("<"+"h"*(vcount*3),raw,0)
                rgb_offset=vcount*6
                rgb=raw[rgb_offset:rgb_offset+vcount*3]
                idx=struct.unpack_from("<"+"I"*icount,raw,rgb_offset+vcount*3)
                bm=MeshBuffer("BP measured LiDAR walls "+tile_id)
                for i in range(vcount):
                    qx,qz,qn=pos[i*3:i*3+3]
                    bm.vertices.append((ax+qx*POSITION_SCALE_M, ay+qn*POSITION_SCALE_M, az+qz*POSITION_SCALE_M))
                for i in range(0,icount,3):
                    bm.faces.append((idx[i],idx[i+1],idx[i+2])); bm.material_ids.append(0)
                wallmat=principled("BP | measured LiDAR facade wall shading "+tile_id,(0.55,0.58,0.59),0.84)
                obj=bm.create_object(col,[wallmat],"BP_MIDTOWN_LIDAR_MEASURED_WALLS_"+tile_id)
        tile_count+=1
    report["midtownLidar"]={"status":"IMPORTED", "tiles":tile_count, "surfaceTriangles":total_triangles,
                            "source": "NYC OTI 2017 topobathymetric LiDAR + NYS 2022-2025 orthophoto; exact 3x3 Midtown tile set",
                            "facadePhotography":False}


def main():
    raw = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir",type=Path,required=True)
    parser.add_argument("--output-dir",type=Path,required=True)
    parser.add_argument("--include-midtown-lidar",action="store_true",default=True)
    parser.add_argument("--max-trees",type=int,default=100000)
    parser.add_argument("--max-windows",type=int,default=1200000)
    args=parser.parse_args(raw)
    source_dir=args.source_dir; output_dir=args.output_dir; output_dir.mkdir(parents=True,exist_ok=True)
    source_manifest_path=source_dir/"source-manifest.json"
    if not source_manifest_path.is_file():
        raise SystemExit("Source manifest is missing. Run download_manhattan_city_sources.py first.")
    source_manifest=json.loads(source_manifest_path.read_text(encoding="utf-8"))
    origin=source_manifest["localOrigin"]
    origin_x=float(origin["projectedXFeet"])*FT_TO_M
    origin_y=float(origin["projectedYFeet"])*FT_TO_M
    report={"startedAtUtc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"sourceManifest":"source-manifest.json",
            "coordinateReference":"EPSG:2263 local ENU metres; Z uses NAVD88-based OTI ground elevations",
            "separatePrototypeCollection":"BP_MANHATTAN_EXCLUSIVE_PREVIEW"}

    bpy.ops.object.select_all(action="SELECT"); bpy.ops.object.delete(use_global=False)
    for c in list(bpy.data.collections):
        if c.name != "Collection": bpy.data.collections.remove(c)
    root=bpy.context.scene.collection
    city=collection("BP_MANHATTAN_EXCLUSIVE_PREVIEW",root)
    buildings_col=collection("01_BUILDINGS_PROCEDURAL_FACADES",city)
    windows_col=collection("02_PROCEDURAL_WINDOWS",city)
    rooftop_col=collection("03_PROCEDURAL_ROOFTOP_EQUIPMENT",city)
    terrain_col=collection("04_TERRAIN_AND_GROUND",city)
    transport_col=collection("05_ROADS_SIDEWALKS_CURBS",city)
    nature_col=collection("06_SOURCED_TREES",city)
    water_col=collection("07_HYDROGRAPHY",city)
    utility_col=collection("08_STREET_UTILITIES",city)

    # Distinct, intentionally restrained architecture/material families.
    wall_mats=[
        principled("BP | prewar masonry / brick proxy",(0.40,0.22,0.15),0.86),
        principled("BP | postwar concrete / stone proxy",(0.48,0.49,0.47),0.84),
        principled("BP | contemporary facade / glass proxy",(0.23,0.31,0.35),0.38,0.18),
        principled("BP | industrial / garage proxy",(0.34,0.36,0.35),0.88),
        principled("BP | construction state proxy",(0.55,0.39,0.22),0.82),
        principled("BP | roof membrane",(0.19,0.20,0.20),0.88),
    ]
    window_mats=[principled("BP | deep window shadow",(0.025,0.045,0.06),0.22,0.15)]
    road_mat=principled("BP | asphalt road bed",(0.055,0.061,0.064),0.93)
    sidewalk_mat=principled("BP | concrete sidewalks",(0.43,0.43,0.40),0.91)
    curb_mat=principled("BP | cut-stone concrete curbs",(0.53,0.53,0.50),0.9)
    water_mat=water_material()
    tree_mats=[principled("BP | tree bark",(0.18,0.105,0.055),0.95),
               principled("BP | broadleaf foliage",(0.065,0.19,0.075),0.93),
               principled("BP | tree crown variation",(0.11,0.25,0.10),0.92)]
    utility_mat=principled("BP | hydrant enamel",(0.67,0.055,0.025),0.42,0.12)

    buildings=load_collection(source_dir/"buildings.geojson")
    boundary_features=load_collection(source_dir/"boundary.geojson")
    roads=load_collection(source_dir/"roads.geojson")
    curbs=load_collection(source_dir/"curbs.geojson")
    sidewalks=load_collection(source_dir/"sidewalks.geojson")
    water=load_collection(source_dir/"water.geojson")
    trees=load_collection(source_dir/"trees.geojson")
    hydrants=load_collection(source_dir/"hydrants.geojson")
    report["sourceFeatureCounts"]={"buildings":len(buildings),"roads":len(roads),"curbs":len(curbs),
                                   "sidewalks":len(sidewalks),"water":len(water),"trees":len(trees),"hydrants":len(hydrants)}

    boundary,terrain_tree=build_terrain(boundary_features,buildings,terrain_col,report)
    # Citywide measured OTI footprints and recorded roof heights, grouped into five style classes.
    building_buffers=[MeshBuffer("BP buildings style "+str(i)) for i in range(5)]
    window_buffer=MeshBuffer("BP procedural facade windows")
    roof_props=MeshBuffer("BP procedural rooftop equipment")
    n_buildings=0; measured_heights=0; estimated_heights=0; n_windows=0; roof_prop_count=0
    minx=miny=float("inf"); maxx=maxy=float("-inf")
    for feature in buildings:
        props=feature.get("properties",{})
        year=prop(props,"CONSTRUCTION_YEAR","construction_year")
        code=prop(props,"FEATURE_CODE","feature_code",default=2100)
        style=style_index(year,code)
        bbuf=building_buffers[style]
        ground_ft=prop(props,"GROUND_ELEVATION","ground_elevation")
        roof_ft=prop(props,"HEIGHT_ROOF","height_roof")
        measured_ground=ground_ft is not None
        try: base_z=float(ground_ft)*FT_TO_M if measured_ground else 0.0
        except (ValueError,TypeError): base_z=0.0; measured_ground=False
        for poly in polygons(feature.get("geometry")):
            if not poly: continue
            outer=ring_xy(poly[0])
            if len(outer)<3: continue
            # Bounding/area values are recomputed from the projected geometry, not SHAPE_AREA.
            for x,y in outer:
                minx=min(minx,x); miny=min(miny,y); maxx=max(maxx,x); maxy=max(maxy,y)
            area=abs(signed_area(outer))
            height_measured=False
            try:
                height=float(roof_ft)*FT_TO_M
                height_measured=height>1.5
            except (ValueError,TypeError):
                height=0.0
            if not height_measured:
                height=estimated_height_m(area,code)
                estimated_heights+=1
            else:
                measured_heights+=1
            height=max(3.5,min(height,360.0))
            # Use a nearest sourced building-base elevation when the feature itself is missing one.
            if not measured_ground and terrain_tree is not None:
                cx,cy=ring_centroid(outer); base_z=terrain_height(terrain_tree,cx,cy)
            top_z=base_z+height
            bottom_vertices=[(x,y,base_z) for x,y in outer]
            top_vertices=[(x,y,top_z) for x,y in outer]
            bbuf.face(top_vertices,5)
            for i in range(len(outer)):
                j=(i+1)%len(outer)
                bbuf.face((bottom_vertices[i],bottom_vertices[j],top_vertices[j],top_vertices[i]),style)
                # A low parapet lip is a generic architectural detail, not a surveyed roof object.
                if height>9.0:
                    roof_lip=0.42
                    bbuf.face(((outer[i][0],outer[i][1],top_z),(outer[j][0],outer[j][1],top_z),
                               (outer[j][0],outer[j][1],top_z+roof_lip),(outer[i][0],outer[i][1],top_z+roof_lip)),style)
                dx,dy=outer[j][0]-outer[i][0],outer[j][1]-outer[i][1]
                length=math.hypot(dx,dy)
                if length>5.0 and height>9.0 and n_windows<args.max_windows:
                    signed=signed_area(outer)
                    normal=(dy/length,-dx/length) if signed>0 else (-dy/length,dx/length)
                    step_x=2.7 if style==0 else 3.1
                    step_z=3.0 if style==0 else 3.4
                    n_windows+=make_window_face(window_buffer,outer[i],outer[j],normal,base_z,length,height,step_x,step_z,1.25,1.55)
            # Roof equipment: deterministic generic HVAC/vents on larger buildings only.
            if area>250.0 and height>6.0:
                seed=int(prop(props,"DOITT_ID","OBJECTID",default=n_buildings+1) or n_buildings+1)
                rng=random.Random(seed)
                items=1 if area<1000 else (2 if area<6000 else 4)
                cx,cy=ring_centroid(outer)
                if not point_in_ring((cx,cy),outer): cx,cy=outer[0]
                for k in range(items):
                    rx=cx+(rng.random()-0.5)*min(18.0,math.sqrt(area)*0.4)
                    ry=cy+(rng.random()-0.5)*min(18.0,math.sqrt(area)*0.4)
                    sx=rng.uniform(1.1,2.4); sy=rng.uniform(0.9,1.8); sz=rng.uniform(0.6,1.6)
                    add_box(roof_props,rx,ry,top_z+0.06,sx,sy,sz,0,rng.uniform(-0.25,0.25))
                    roof_prop_count+=1
            n_buildings+=1
    for i,bbuf in enumerate(building_buffers):
        obj=bbuf.create_object(buildings_col,wall_mats,"BP_BUILDINGS_STYLE_"+str(i))
        if obj: obj["detail_truth"]="Footprint + roof height from NYC OTI; architectural appearance procedurally generated"
    wobj=window_buffer.create_object(windows_col,window_mats,"BP_PROCEDURAL_FACADE_WINDOWS")
    if wobj: wobj["detail_truth"]="Procedural window repetition; not individual surveyed window positions or facade photography"
    robj=roof_props.create_object(rooftop_col,[principled("BP | rooftop equipment light metal",(0.39,0.41,0.42),0.76)],"BP_PROCEDURAL_ROOFTOP_HVAC_AND_VENTS")
    if robj: robj["detail_truth"]="Procedural proxy props; not city-surveyed rooftop inventory"

    road_segments=build_road_ribbons(roads,transport_col,road_mat,terrain_tree)
    sidewalk_faces=build_surfaces("BP_NYC_SIDEWALKS | measured planimetric polygons",sidewalks,transport_col,sidewalk_mat,"sidewalk",terrain_tree)
    curb_obj=add_curb_curves(curbs,transport_col,terrain_tree,[curb_mat])
    water_faces=build_surfaces("BP_NYC_HYDROGRAPHY | sourced water polygons",water,water_col,water_mat,"water",None)

    tree_buffer=MeshBuffer("BP trees | source point placement with procedural canopy forms")
    tree_count=0
    for feature in trees[:args.max_trees]:
        props=feature.get("properties",{})
        species=prop(props,"GenusSpecies","genusspecies",default="unknown urban tree")
        for p in points(feature.get("geometry")):
            if len(p)<2: continue
            x,y=float(p[0]),float(p[1]); z=terrain_height(terrain_tree,x,y)
            import zlib
            seed=zlib.crc32(str(prop(props,"GlobalID","globalid","OBJECTID",default=tree_count)).encode("utf-8")) & 0xffffffff
            add_tree_instance(tree_buffer,x,y,z,species,seed)
            tree_count+=1
    tree_obj=tree_buffer.create_object(nature_col,tree_mats,"BP_NYC_TREES | ForMS locations + procedural tree proxy meshes")
    if tree_obj: tree_obj["detail_truth"]="Tree point/species attributes from NYC Parks ForMS 2.0; mesh canopy generated procedurally"
    hydrant_count=build_hydrants(hydrants,utility_col,terrain_tree,utility_mat)

    if args.include_midtown_lidar:
        import_midtown_lidar(source_dir/"lidar",city,(origin_x,origin_y),report)

    # Camera/light are only for a useful first-open preview, not an animation or rendered claim.
    scene=bpy.context.scene
    try:
        scene.render.engine="BLENDER_EEVEE_NEXT"
    except Exception:
        scene.render.engine="BLENDER_EEVEE"
    scene.render.resolution_x=1600; scene.render.resolution_y=1000; scene.render.resolution_percentage=100
    world=bpy.data.worlds.new("BP Manhattan preview sky") if not bpy.data.worlds else bpy.data.worlds[0]
    scene.world=world; world.use_nodes=True
    world.node_tree.nodes["Background"].inputs["Color"].default_value=(0.20,0.27,0.34,1)
    world.node_tree.nodes["Background"].inputs["Strength"].default_value=0.42
    sun_data=bpy.data.lights.new("BP Manhattan Sun","SUN"); sun_data.energy=2.0
    sun=bpy.data.objects.new("BP Manhattan Sun",sun_data); city.objects.link(sun)
    sun.rotation_euler=(math.radians(28),math.radians(-25),math.radians(-35))
    scene.render.image_settings.file_format="PNG"
    if math.isfinite(minx) and math.isfinite(maxx):
        target=Vector(((minx+maxx)*0.5,(miny+maxy)*0.5,18.0))
        cam_data=bpy.data.cameras.new("BP Manhattan overview camera")
        camera=bpy.data.objects.new("BP Manhattan overview camera",cam_data)
        city.objects.link(camera)
        camera.location=target+Vector((8500.0,-11500.0,8500.0))
        direction=target-camera.location
        camera.rotation_euler=direction.to_track_quat("-Z","Y").to_euler()
        cam_data.lens=42.0; cam_data.clip_end=100000.0
        scene.camera=camera

    report.update({"status":"BUILT_STANDALONE_PREVIEW","buildingCount":n_buildings,
                   "buildingMeasuredRoofHeightCount":measured_heights,"buildingFallbackHeightCount":estimated_heights,
                   "proceduralWindowQuadCount":n_windows,"proceduralRooftopPropCount":roof_prop_count,
                   "roadRibbonSegmentCount":road_segments,"sidewalkPolygonCount":sidewalk_faces,
                   "curbLayerPresent":bool(curbs),"waterPolygonCount":water_faces,
                   "treeInstanceCount":tree_count,"hydrantCount":hydrant_count,
                   "modelExtentLocalMeters":{"minX":minx,"minY":miny,"maxX":maxx,"maxY":maxy},
                   "visualTruthNotes":[
                       "Citywide OTI building footprints and reported roof heights are source data; missing/zero heights are approximated from footprint area.",
                       "Window grids, parapets, facade material families, rooftop HVAC/vents, and tree meshes are procedural visualization details, not surveyed assets.",
                       "Road surface widths are estimated from street-name class; centerline geometry is sourced. Curbs and sidewalks are sourced planimetrics.",
                       "The citywide terrain is interpolated from building base elevations, not a continuous citywide LiDAR DTM.",
                       "The included high-resolution orthophoto/LiDAR surface covers the existing nine Midtown tiles only; it does not cover the entire Manhattan island.",
                       "No citywide oblique facade imagery or actual per-window geometry is present in the public inputs."
                   ],
                   "generatedAtUtc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())})
    report_path=output_dir/"manhattan-build-report.json"
    report_path.write_text(json.dumps(report,indent=2),encoding="utf-8")
    scene.render.filepath=str(output_dir/"manhattan-preview.png")
    # Save editable Blender scene and interchange GLB; both live outside the application repo.
    bpy.ops.wm.save_as_mainfile(filepath=str(output_dir/"bridgepoint-manhattan-city.blend"))
    try:
        try:
            bpy.ops.preferences.addon_enable(module="io_scene_gltf2")
        except Exception:
            pass
        bpy.ops.export_scene.gltf(filepath=str(output_dir/"bridgepoint-manhattan-city.glb"),export_format="GLB",
                                  export_apply=True,export_texcoords=True,export_normals=True,
                                  export_materials="EXPORT",export_image_format="AUTO",export_yup=True,
                                  export_cameras=False,export_lights=False)
        report["glbExport"]="PASS"
    except Exception as exc:
        report["glbExport"]="FAILED: "+str(exc)
    report_path.write_text(json.dumps(report,indent=2),encoding="utf-8")
    print("MANHATTAN_BLENDER_BUILD_COMPLETE",json.dumps({k:report.get(k) for k in (
        "status","buildingCount","buildingMeasuredRoofHeightCount","buildingFallbackHeightCount",
        "proceduralWindowQuadCount","roadRibbonSegmentCount","sidewalkPolygonCount","waterPolygonCount",
        "treeInstanceCount","hydrantCount","midtownLidar","glbExport")}),flush=True)

if __name__=="__main__":
    main()
